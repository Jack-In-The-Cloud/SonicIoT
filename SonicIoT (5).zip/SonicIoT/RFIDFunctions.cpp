#include "RFIDFunctions.h"
#include <M5StickCPlus2.h>

#define RST_PIN 22
#define SS_PIN 21
MFRC522 rfid(SS_PIN, RST_PIN); // Define rfid

void initializeRFID() {
  SPI.begin();
  rfid.PCD_Init();
}

void readRFID() {
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.println("Reading RFID Tag...");

  if (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial()) {
    M5.Lcd.print("Tag UID: ");
    for (byte i = 0; i < rfid.uid.size; i++) {
      M5.Lcd.print(rfid.uid.uidByte[i] < 0x10 ? " 0" : " ");
      M5.Lcd.print(rfid.uid.uidByte[i], HEX);
    }
    M5.Lcd.println();
    rfid.PICC_HaltA();
  } else {
    M5.Lcd.println("No RFID Tag Found");
  }
}

void deleteRFID() {
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.println("Deleting RFID Tag...");

  // Implement RFID delete functionality here

  M5.Lcd.println("RFID Tag Deleted");
}
