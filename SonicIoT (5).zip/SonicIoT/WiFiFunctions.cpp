#include "WiFiFunctions.h"
#include <WiFi.h>
#include <esp_wifi.h>
#include <M5StickCPlus2.h>
#include "Globals.h"

void initializeWiFi() {
  const char* ssid = "your_SSID";
  const char* password = "your_PASSWORD";

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);  // Reduced delay
  }
}

void beaconSpam() {
  // Existing code...
}

void fullJam() {
  // Existing code...
}
