#include "SpamFunctions.h"
#include <M5StickCPlus2.h>

void iosSpam() {
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.println("Starting iOS Spam...");

  // Your iOS spam functionality here

  M5.Lcd.println("iOS Spam Stopped");
}

void androidSpam() {
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.println("Starting Android Spam...");

  // Your Android spam functionality here

  M5.Lcd.println("Android Spam Stopped");
}

void windowsSpam() {  // Add this function
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.println("Starting Windows Spam...");

  // Your Windows spam functionality here

  M5.Lcd.println("Windows Spam Stopped");
}

void broadcastFM() {
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.println("Starting FM Broadcast...");

  // Your FM broadcast functionality here

  M5.Lcd.println("FM Broadcast Stopped");
}
