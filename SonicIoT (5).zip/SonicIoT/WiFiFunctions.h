#ifndef WIFIFUNCTIONS_H
#define WIFIFUNCTIONS_H

void initializeWiFi();
void beaconSpam();
void fullJam();
void displayMessage(const char* message);

#endif
