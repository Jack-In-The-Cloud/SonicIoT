#ifndef GLOBALS_H
#define GLOBALS_H

enum State {
  MAIN_MENU,
  WIFI_MENU,
  BLE_MENU,
  SPAM_MENU,
  MISC_MENU
};

extern State currentState;
extern bool stopFlag;

#endif
