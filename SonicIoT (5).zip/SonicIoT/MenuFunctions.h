#ifndef MENUFUNCTIONS_H
#define MENUFUNCTIONS_H

#include "Globals.h"

void displayMainMenu();
void displayWiFiMenu();
void displayBLEMenu();
void updateMenu();

#endif
