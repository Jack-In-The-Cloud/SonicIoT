#include "MenuFunctions.h"
#include "WiFiFunctions.h"
#include "BLEFunctions.h"
#include "RFIDFunctions.h"
#include "SpamFunctions.h"
#include <M5StickCPlus2.h>

void displayMessage(const char* message) {
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.println(message);
}

void displayMainMenu() {
  currentState = MAIN_MENU;
  displayMessage("1. WiFi Attacks\n2. Bluetooth Attacks\n3. Spam Attacks\n4. Miscellaneous");
}

void displayWiFiMenu() {
  currentState = WIFI_MENU;
  displayMessage("1. Beacon Spam\n2. Full Jam");
}

void displayBLEMenu() {
  currentState = BLE_MENU;
  displayMessage("1. Bad BLE\n2. Jam NRF24");
}

void updateMenu() {
  switch (currentState) {
    case MAIN_MENU:
      if (M5.BtnA.wasPressed()) displayWiFiMenu();
      if (M5.BtnB.wasPressed()) displayBLEMenu();
      break;
    case WIFI_MENU:
      if (M5.BtnA.wasPressed()) { stopFlag = false; beaconSpam(); }
      if (M5.BtnB.wasPressed()) { stopFlag = false; fullJam(); }
      if (M5.BtnA.pressedFor(2000)) displayMainMenu();
      break;
    case BLE_MENU:
      if (M5.BtnA.wasPressed()) { stopFlag = false; badBLE(); }
      if (M5.BtnB.wasPressed()) { stopFlag = false; jamNRF24(); }
      if (M5.BtnA.pressedFor(2000)) displayMainMenu();
      break;
    // Add cases for other menus as needed...
    default:
      displayMainMenu(); // Fallback to main menu if state is unrecognized
      break;
  }
}
