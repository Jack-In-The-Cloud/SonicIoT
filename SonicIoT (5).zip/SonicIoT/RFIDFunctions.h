#ifndef RFIDFUNCTIONS_H
#define RFIDFUNCTIONS_H

#include <MFRC522.h>
#include "Globals.h"

void initializeRFID();
void readRFID();
void deleteRFID();

extern MFRC522 rfid; // Declare rfid as extern

#endif
