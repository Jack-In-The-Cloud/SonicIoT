#include "arduino_secrets.h"

#include <Utilities.h>
#define USE_WIFI
#define USE_BLUETOOTH

#include <M5StickCPlus2.h>
#include "MenuFunctions.h"
#include "WiFiFunctions.h"
#include "BLEFunctions.h"
#include "RFIDFunctions.h"
#include "SpamFunctions.h"


void setup() {
  M5.begin();
  initializeWiFi();
  initializeBluetooth();
  initializeRFID();
  displayMainMenu();
}

void loop() {
  updateMenu();
}
