#include "BLEFunctions.h"
#include <BluetoothSerial.h>
#include <M5StickCPlus2.h>
#include "Globals.h"

BluetoothSerial SerialBT;

void initializeBluetooth() {
  SerialBT.begin("SonicBT");
}

void badBLE() {
  // Implement bad BLE functionality here
}

void jamNRF24() {
  // Implement NRF24 jammer functionality here
}
