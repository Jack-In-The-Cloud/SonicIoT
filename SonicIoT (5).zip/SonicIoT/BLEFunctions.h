#ifndef BLEFUNCTIONS_H
#define BLEFUNCTIONS_H

void initializeBluetooth();
void badBLE();
void jamNRF24();

#endif
