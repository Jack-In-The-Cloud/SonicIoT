#include "Globals.h"

State currentState = MAIN_MENU;
bool stopFlag = false;
