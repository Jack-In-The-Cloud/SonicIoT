#ifndef SPAMFUNCTIONS_H
#define SPAMFUNCTIONS_H

#include "Globals.h"

void iosSpam();
void androidSpam();
void windowsSpam();
void broadcastFM();

#endif
